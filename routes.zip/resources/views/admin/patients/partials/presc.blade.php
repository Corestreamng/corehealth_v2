{{-- Prescription Management Tab --}}
{{-- Uses unified prescription component with card layout and AJAX operations --}}

@include('admin.patients.partials.presc_unified')

