@extends('admin.layouts.app')
@section('title', 'Create Staff')
@section('page_name', 'Staff')
@section('subpage_name', 'Create Staff')
@section('style')
    @php
        $primaryColor = appsettings()->hos_color ?? '#011b33';
    @endphp
    <style>
        :root {
            --primary-color: {{ $primaryColor }};
            --primary-light: {{ $primaryColor }}15;
        }
    </style>
    <link rel="stylesheet" href="{{ asset('css/modern-forms.css') }}">
@endsection
@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card-modern">
                <div class="card-header-modern d-flex justify-content-between align-items-center">
                    <div>
                        <h2 class="mb-1 font-weight-bold text-dark">Create New Staff</h2>
                        <p class="text-muted mb-0">Add a new staff member to the system</p>
                    </div>
                </div>
                <div class="card-body p-3">
                    {!! Form::open(['method' => 'POST', 'route' => 'staff.store', 'class' => 'form-horizontal', 'enctype' => 'multipart/form-data']) !!}
                    {{ csrf_field() }}

            <div class="row">
                <!-- Left Column: Image & Files -->
                <div class="col-lg-3">
                    <div class="card-modern">
                        <div class="card-header-modern">
                            <h5 class="card-title-modern">
                                <i class="mdi mdi-camera-outline text-primary"></i> Profile Image
                            </h5>
                        </div>
                        <div class="card-body text-center p-3">
                            <img src="{{ asset('img/avatar-placeholder.png') }}" id="preview-img" class="preview-image mb-3" style="width: 100px; height: 100px;">
                            <div class="upload-zone">
                                <input type="file" name="filename" id="filename" accept="image/*" onchange="previewImage(this)">
                                <i class="mdi mdi-cloud-upload upload-icon"></i>
                                <p class="mb-0 font-weight-bold">Click to upload</p>
                                <small class="text-muted">JPG, PNG up to 2MB</small>
                            </div>
                        </div>
                    </div>

                    <div class="card-modern">
                        <div class="card-header-modern">
                            <h5 class="card-title-modern">
                                <i class="mdi mdi-file-document-outline text-primary"></i> Documents
                            </h5>
                        </div>
                        <div class="card-body p-3">
                            <label class="form-label-modern">Old Records</label>
                            <input type="file" class="form-control form-control-modern" id="old_records" name="old_records" style="height: auto; padding: 0.5rem;">
                            <small class="text-muted mt-2 d-block">Upload historical records.</small>
                        </div>
                    </div>
                </div>

                <!-- Right Column: Details -->
                <div class="col-lg-9">
                    <!-- Personal Information -->
                    <div class="card-modern">
                        <div class="card-header-modern">
                            <h5 class="card-title-modern">
                                <i class="mdi mdi-account-details-outline text-primary"></i> Personal Information
                            </h5>
                        </div>
                        <div class="card-body p-3">
                            <div class="row g-3">
                                <div class="col-lg-4 col-md-6">
                                    <label class="form-label-modern">Surname <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-modern" name="surname" value="{{ old('surname') }}" placeholder="e.g. Doe" required>
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <label class="form-label-modern">Firstname <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-modern" name="firstname" value="{{ old('firstname') }}" placeholder="e.g. John" required>
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <label class="form-label-modern">Othername</label>
                                    <input type="text" class="form-control form-control-modern" name="othername" value="{{ old('othername') }}" placeholder="Middle name">
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <label class="form-label-modern">Gender <span class="text-danger">*</span></label>
                                    <select class="form-control form-control-modern" name="gender" required>
                                        <option value="">Select gender</option>
                                        <option value="Male" {{(old('gender') == 'Male') ? 'selected': ''}}>Male</option>
                                        <option value="Female" {{(old('gender') == 'Female') ? 'selected': ''}}>Female</option>
                                        <option value="Others" {{(old('gender') == 'Others') ? 'selected': ''}}>Others</option>
                                    </select>
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <label class="form-label-modern">Date of Birth <span class="text-danger">*</span></label>
                                    <input type="date" class="form-control form-control-modern" name="dob" value="{{old('dob')}}" required>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Professional Details -->
                    <div class="card-modern">
                        <div class="card-header-modern">
                            <h5 class="card-title-modern">
                                <i class="mdi mdi-doctor text-primary"></i> Professional Details
                            </h5>
                        </div>
                        <div class="card-body p-3">
                            <div class="row g-3">
                                <div class="col-lg-4 col-md-6">
                                    <label class="form-label-modern">Staff Category <span class="text-danger">*</span></label>
                                    {!! Form::select('statuses', $statuses, old('is_admin'), ['class' => 'form-control form-control-modern select2', 'placeholder' => 'Select Category', 'required' => 'true']) !!}
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <label class="form-label-modern">Specialization <small class="text-muted">(Doctors)</small></label>
                                    {!! Form::select('specializations', $specializations, old('specialization'), ['class' => 'form-control form-control-modern select2', 'placeholder' => 'Select Specialization']) !!}
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <label class="form-label-modern">Clinic <small class="text-muted">(Doctors)</small></label>
                                    {!! Form::select('clinics', $clinics, old('clinics'), ['class' => 'form-control form-control-modern select2', 'placeholder' => 'Select Clinic']) !!}
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <label class="form-label-modern">Consultation Fee <small class="text-muted">(Doctors)</small></label>
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">NGN</span>
                                        </div>
                                        <input type="number" name="consultation_fee" class="form-control form-control-modern" value="{{old('consultation_fee')}}">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Contact Details -->
                    <div class="card-modern">
                        <div class="card-header-modern">
                            <h5 class="card-title-modern">
                                <i class="mdi mdi-card-account-mail-outline text-primary"></i> Contact Details
                            </h5>
                        </div>
                        <div class="card-body p-3">
                            <div class="row g-3">
                                <div class="col-lg-4 col-md-6">
                                    <label class="form-label-modern">Email Address <span class="text-danger">*</span></label>
                                    <input type="email" class="form-control form-control-modern" name="email" value="{{ old('email') }}" placeholder="email@example.com" required>
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <label class="form-label-modern">Phone Number <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control form-control-modern" name="phone_number" value="{{ old('phone_number') }}" placeholder="+234..." required>
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <label class="form-label-modern">Residential Address</label>
                                    <textarea class="form-control form-control-modern" name="address" rows="3" placeholder="Enter full address">{{ old('address') }}</textarea>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Security & Access -->
                    <div class="card-modern">
                        <div class="card-header-modern">
                            <h5 class="card-title-modern">
                                <i class="mdi mdi-shield-lock-outline text-primary"></i> Security & Access
                            </h5>
                        </div>
                        <div class="card-body p-3">
                            <div class="row g-3">
                                <div class="col-lg-6 col-md-6">
                                    <label class="form-label-modern">Password <span class="text-danger">*</span></label>
                                    <input type="password" class="form-control form-control-modern" name="password" value="123456" required>
                                    <small class="text-muted">Default: 123456</small>
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <label class="form-label-modern">Password <span class="text-danger">*</span></label>
                                    <input type="password" class="form-control form-control-modern" name="password" placeholder="Minimum 8 characters" required>
                                </div>
                            </div>

                            <hr class="my-3">

                            <div class="row g-3">
                                <div class="col-lg-4 col-md-6">
                                    <div class="custom-control custom-checkbox mb-2">
                                        <input type="checkbox" class="custom-control-input" id="assignRole" name="assignRole">
                                        <label class="custom-control-label font-weight-bold" for="assignRole">Assign Roles</label>
                                    </div>
                                    {!! Form::select('roles[]', $roles, [], ['class' => 'form-control form-control-modern select2', 'multiple', 'style' => 'width: 100%;', 'data-placeholder' => 'Select roles...']) !!}
                                </div>
                                <div class="col-lg-4 col-md-6">
                                    <div class="custom-control custom-checkbox mb-2">
                                        <input type="checkbox" class="custom-control-input" id="assignPermission" name="assignPermission">
                                        <label class="custom-control-label font-weight-bold" for="assignPermission">Assign Permissions</label>
                                    </div>
                                    {!! Form::select('permissions[]', $permissions, [], ['class' => 'form-control form-control-modern select2', 'multiple', 'style' => 'width: 100%;', 'data-placeholder' => 'Select permissions...']) !!}
                                </div>
                            </div>

                            <hr class="my-3">

                            <!-- Leadership Roles -->
                            <div class="row g-3">
                                <div class="col-12">
                                    <label class="form-label-modern d-block mb-2">
                                        <i class="mdi mdi-shield-crown-outline text-primary"></i> Leadership Roles
                                    </label>
                                    <div class="d-flex flex-wrap gap-4" style="gap: 1.5rem;">
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input" id="is_unit_head" name="is_unit_head" value="1" {{ old('is_unit_head') ? 'checked' : '' }}>
                                            <label class="custom-control-label" for="is_unit_head">
                                                <span class="font-weight-bold text-info">Unit Head</span>
                                                <small class="d-block text-muted">Leads a specific unit within a department</small>
                                            </label>
                                        </div>
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input" id="is_dept_head" name="is_dept_head" value="1" {{ old('is_dept_head') ? 'checked' : '' }}>
                                            <label class="custom-control-label" for="is_dept_head">
                                                <span class="font-weight-bold text-warning">Department Head</span>
                                                <small class="d-block text-muted">Leads an entire department</small>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="card-footer bg-white border-top py-3">
                <div class="d-flex justify-content-end gap-2">
                    <a href="{{ route('staff.index') }}" class="btn btn-light border px-4">Cancel</a>
                    <button type="submit" class="btn btn-primary-modern px-4">
                        <i class="mdi mdi-check mr-1"></i> Create Staff
                    </button>
                </div>
            </div>
            {!! Form::close() !!}
        </div>
    </div>
</div>
</div>
@endsection

@section('scripts')
    {{-- <script src="{{ asset('plugins/jQuery/jquery.min.js') }}"></script> --}}
    {{-- <script src="{{ asset('/plugins/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('plugins/select2/select2.min.js') }}"></script>
    <script src="{{ asset('plugins/ckeditor/ckeditor.js') }}"></script> --}}
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta3/js/bootstrap-select.min.js" integrity="sha512-yrOmjPdp8qH8hgLfWpSFhC/+R9Cj9USL8uJxYIveJZGAiedxyIxwNw4RsLDlcjNlIRR4kkHaDHSmNHAkxFTmgg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script> -->

    <script>
        //  CKEDITOR.replace('content');
    </script>

    <script>
        $(document).ready(function() {
            // $.noConflict();
            // CKEDITOR.replace('content');
            $(".select2").select2();
        });
    </script>

    <script type="text/javascript">
        function readURL() {
            var myimg = document.getElementById("myimg");
            var input = document.getElementById("filename");
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    console.log("changed");
                    myimg.src = e.target.result;
                }
                reader.readAsDataURL(input.files[0]);
            }
        }

        document.querySelector('#filename').addEventListener('change', function() {
            readURL()
        });
    </script>
@endsection
