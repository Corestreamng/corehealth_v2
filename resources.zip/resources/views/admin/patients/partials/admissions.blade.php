<div class="table-responsive">
    <table id="admission-request-list" class="table table-sm table-bordered table-striped"
        style="width: 100%">
        <thead>
            <tr>
                <th>SN</th>
                <th>Requested By</th>
                <th>Bills</th>
                <th>Bed</th>
                <th>View</th>
            </tr>
        </thead>
    </table>
</div>