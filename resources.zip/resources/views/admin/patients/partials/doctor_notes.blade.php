<div class="table-responsive">
    <table class="table table-sm table-bordered table-striped" style="width: 100%"
        id="encounter_history_list">
        <thead>
            <th>#</th>
            {{-- <th>Doctor</th> --}}
            <th>Notes</th>
            {{-- <th>Time</th> --}}
        </thead>
    </table>
</div>