<div class="table-responsive">
    <table class="table table-hover" style="width: 100%"
        id="encounter_history_list">
        <thead class="table-light">
            <th><i class="mdi mdi-note-multiple"></i> Encounter Notes</th>
        </thead>
    </table>
</div>
